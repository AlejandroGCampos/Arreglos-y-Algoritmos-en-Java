package umg.edu.gt.data_structure.array;

import java.util.Arrays;

public class MergeSortDemo {

    public void mergeSort(int[] a) { //metodo de inicio de proceso de ordenamiento
        if (a.length <= 1) //Metodo el que inicia el proceso de ordenamiento
            return;

        int mid = a.length / 2; //divide el arreglo y calcula el punto medio
        int[] left = Arrays.copyOfRange(a, 0, mid);
        int[] right = Arrays.copyOfRange(a, mid, a.length);

        mergeSort(left); // se llama asi mismo para ordenar cada mitad (derecha e izquierda)
        mergeSort(right);
        merge(a, left, right); //despues ordena cada mitad y las combina en orden
    }

    private void merge(int[] a, int[] left, int[] right) { //metodo de union en los arreglos left y right a uno solo
        int i = 0, j = 0, k = 0;

        while (i < left.length && j < right.length) { //compara elemento por elemento
            if (left[i] <= right[j]) { //el menor se guarda en el arreglo original a
                a[k++] = left[i++];
            } else {
                a[k++] = right[j++];
            }
        }

        while (i < left.length) //si queda algo en left lo copia
            a[k++] = left[i++];

        while (j < right.length) //si queda algo en right lo copia
            a[k++] = right[j++];
    }
}
