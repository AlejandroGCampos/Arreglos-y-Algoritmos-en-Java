package umg.edu.gt.data_structure.array;

public class BubbleSort {

    public void bubbleSort(int[] arr) {
        int n = arr.length; //Esto guarda cuántos elementos tiene el arreglo

        for (int i = 0; i < n - 1; i++) { //Pasa varias veces sobre el arreglo y en cada pasada sube el más grande y reduce el rango por vuelta con n - 1 - i
            boolean swapped = false;// si en una pasada no hubo cambio, sig que el arreglo ya esta ordenado

            for (int j = 0; j < n - 1 - i; j++) {
                if (arr[j] > arr[j + 1]) { //Compara elementos consecutivos
                    int temp = arr[j]; //Así los numeros grandes se van moviendo a la derecha
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                    swapped = true;
                }
            }

            if (!swapped)// se detiene para no recorrer de forma innecesaria
                break;
        }
    }
}
