package umg.edu.gt.data_structure.array;

public class SumArray { //La clase contiene un metodo que recibe un arreglo de numeros enteros y calcula la suma total de sus elementos usando el ciclo for-each

    public int sum(int[] nums) {
        int total = 0;
        for (int n : nums) {
            total += n;
        }
        return total;
    }
}
