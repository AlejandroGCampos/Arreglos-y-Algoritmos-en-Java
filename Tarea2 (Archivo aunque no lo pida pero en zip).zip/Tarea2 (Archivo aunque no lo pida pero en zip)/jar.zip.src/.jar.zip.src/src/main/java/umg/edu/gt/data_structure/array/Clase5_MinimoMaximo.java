package umg.edu.gt.data_structure.array;

public class Clase5_MinimoMaximo {
	public void findSecondMinMax(int[] arr) {
		
        if (arr == null || arr.length < 2) { // Verificqdor de seguridad, ya sea si el arreglo es pequeño no hay segundos
            System.out.println("El arreglo debe tener al menos 2 elementos.");
            return;
        }

        int mayor1 = Math.max(arr[0], arr[1]); // Inicializa usando los primeros elementos asi evitando valores basura
        int mayor2 = Math.min(arr[0], arr[1]);
        int menor1 = Math.min(arr[0], arr[1]);
        int menor2 = Math.max(arr[0], arr[1]);

        // Usamos while variando la estructura
        int i = 2; 
        while (i < arr.length) {
            int actual = arr[i];

            if (actual != mayor1) { // Lógica de comparación de extremos maximos
                if (actual > mayor1) {
                    mayor2 = mayor1;
                    mayor1 = actual;
                } else if (actual > mayor2) {
                    mayor2 = actual;
                }
            }

            if (actual != menor1) { // Lógica de comparación de extremos minimos
                if (actual < menor1) {
                    menor2 = menor1;
                    menor1 = actual;
                } else if (actual < menor2) {
                    menor2 = actual;
                }
            }
            
            i++; // Incremento
        }

        // Salida de datos
        System.out.println(">>> Análisis de Arreglo <<<");
        System.out.println("Segundo valor más alto: " + mayor2);
        System.out.println("Segundo valor más bajo: " + menor2);
    }
}
